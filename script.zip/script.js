var map;

function createMap() {
  var position = [-26.0324, 28.0742];
  var diff = 0.0033;

  var options = {
    center: { lat: position[0], lng: position[1] },
    mapTypeId: 'terrain',
    zoom: 14
  };

  map = new google.maps.Map(document.getElementById('map'), options);

  var polygonCoordinates = [
    { lat: position[0] - diff, lng: position[1] - diff },
    { lat: position[0] + diff, lng: position[1] - diff },
    { lat: position[0] + diff, lng: position[1] + diff },
    { lat: position[0] - diff, lng: position[1] + diff },
  ];



  var polygon = new google.maps.Polygon({
    map: map,
    paths: polygonCoordinates,
    strokeColor: 'blue',
    fillColor: 'blue',
    fillOpacity: 0.4,
    draggable: true,
    editable: true
  });

  var marker = new google.maps.Marker({
    position: options.center,
    map: map,
    title: "Latitude:"+position[0]+" | Longitude:"+position[1]
  });
  //marker.setMap(map);



  google.maps.event.addListener(polygon.getPath(), 'set_at', function () {
    logArray(polygon.getPath());
  });
  google.maps.event.addListener(polygon.getPath(), 'insert_at', function () {
    logArray(polygon.getPath());
  });
}

var numDeltas = 100;
var delay = 10; //milliseconds
var i = 0;
var deltaLat;
var deltaLng;

function transition(result) {
  i = 0;
  deltaLat = (result[0] - position[0]) / numDeltas;
  deltaLng = (result[1] - position[1]) / numDeltas;
  moveMarker();
}

function moveMarker() {
  position[0] += deltaLat;
  position[1] += deltaLng;
  var latlng = new google.maps.LatLng(position[0], position[1]);
  marker.setTitle("Latitude:" + position[0] + " | Longitude:" + position[1]);
  marker.setPosition(latlng);
  if (i != numDeltas) {
    i++;
    setTimeout(moveMarker, delay);
  }
}

function logArray(array) {
  var vertices = [];

  for (var i = 0; i < array.getLength(); i++) {
    vertices.push({
      lat: array.getAt(i).lat(),
      lng: array.getAt(i).lng()
    });
  }

  console.log(vertices);
}
